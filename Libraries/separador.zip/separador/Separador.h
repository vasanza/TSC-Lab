//Creado por Pablo Sánchez (Ioticos) para ser compartido, modificado, mejorado sin necesidad de autorización alguna.
//Saludos!

#include <Arduino.h>

#ifndef Separador_h
#define Separador_h


class Separador {
public:

	Separador();
	String separa(String data, char separator, int index);

private:

};

#endif
